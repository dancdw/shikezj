#
# TABLE STRUCTURE FOR: m_recommend
#

DROP TABLE IF EXISTS `m_recommend`;

CREATE TABLE `m_recommend` (
  `area_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `area_title` varchar(100) NOT NULL DEFAULT '' COMMENT '位置标题',
  `area_html` text COMMENT '广告HTML或者描述文本',
  `area_remarks` varchar(1000) NOT NULL DEFAULT '' COMMENT '备注',
  `area_logo` varchar(200) NOT NULL DEFAULT '' COMMENT '位置LOGO图',
  `area_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `area_ids` text NOT NULL COMMENT 'ID列表，用逗号分割',
  `area_type` tinyint(4) NOT NULL COMMENT '1pc网站 2手助 3wap',
  `operate_type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '操作类型1.手动添加2.自动获取',
  `auto_type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '获取类型1.最新更新2.下载排行',
  PRIMARY KEY (`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COMMENT='推荐位置';

INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('30', '最受欢迎', '', '最受欢迎（PC网站首页）', '', '0', '1,2,3', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('31', '装机必备', '', '装机必备（PC网站首页）', '', '0', '1,2,3', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('29', '今日热门推荐', '', '今日热门推荐（PC网站首页）', '', '0', '4,5,6,7,8', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('32', '时下热门', '', '时下热门（手助端首页）', '', '0', '1,2,3,8', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('33', '精品推荐', '', '精品推荐（手助端首页）', '', '0', '1,2,3', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('34', '每日推荐', '', '每日推荐（手助端首页）', '', '0', '1,2,3,4,5,6,7,8,9', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('35', '上升最快', '', '上升最快（手助端首页）', '', '0', '1,2,3', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('36', '装机必备', '', '装机必备（手助端首页）', '', '0', '1,2,3', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('37', '下载排行', '', '下载排行（手助端首页）', '', '0', '1,2,3', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('38', '应用排行', '', '应用排行（手助端排行页）', '', '0', '1,2,3', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('39', '游戏排行', '', '游戏排行（手助端排行页）', '', '0', '1,2,3', '2', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('40', '今日推荐', '', '今日推荐（PC网站首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('41', '精品推荐', '', '精品推荐（PC网站首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('42', '热门排行', '', '热门排行（PC网站首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('44', '飙升榜', '', '飙升榜（PC网站首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('45', '热门', '', '软件热门（wap首页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('46', '热门', '', '游戏热门（wap首页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('47', '精品', '', '软件精品（wap首页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('48', '精品', '', '游戏精品（wap首页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('49', '飙升', '', '软件飙升（wap首页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('50', '飙升', '', '游戏飙升（wap首页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('51', '排行榜', '', '软件飙升（wap排行榜页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('52', '排行榜', '', '游戏飙升（wap排行榜页mobile-1）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('53', '最受欢迎', '', '最受欢迎（wap1最受欢迎页）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('54', '软件', '', '软件（template-3首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('55', '游戏', '', '游戏（template-3首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('56', '飙升排行榜', '', '飙升排行榜-软件（template-3首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('57', '飙升排行榜', '', '飙升排行榜-游戏（template-3首页）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('58', '精品推荐', '', '精品推荐（PC网站软件页template-3）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('59', '精品推荐', '', '精品推荐（PC网站游戏页template-3）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('60', '下载排行', '', '下载排行（PC网站软件页template-3|template-4）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('61', '上升最快', '', '上升最快（PC网站软件页template-3）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('62', '时下热门', '', '时下热门（PC网站软件页template-3）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('63', '下载排行', '', '下载排行（PC网站游戏页template-3|template-4）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('64', '上升最快', '', '上升最快（PC网站游戏页template-3）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('65', '时下热门', '', '时下热门（PC网站游戏页template-3）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('66', '下载排行', '', '下载排行（PC网站新闻页template-3|template-4）', '', '0', '1,2,3,4,5,6,7,8,9', '1', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('67', '精品推荐', '', '精品推荐（wap首页mobile-2）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('68', '下载排行', '', '下载排行（wap首页mobile-2）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');
INSERT INTO `m_recommend` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `area_type`, `operate_type`, `auto_type`) VALUES ('69', '上升最快', '', '上升最快（wap首页mobile-2）', '', '0', '1,2,3,4,5,6,7,8,9', '3', '1', '0');


