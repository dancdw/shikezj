#
# TABLE STRUCTURE FOR: m_flink
#

DROP TABLE IF EXISTS `m_flink`;

CREATE TABLE `m_flink` (
  `flink_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情ID',
  `flink_name` varchar(100) NOT NULL DEFAULT '' COMMENT '链接文字',
  `flink_img` varchar(500) NOT NULL DEFAULT '' COMMENT '链接图片',
  `flink_url` varchar(500) NOT NULL DEFAULT '' COMMENT '链接地址',
  `flink_type` tinyint(3) unsigned DEFAULT NULL COMMENT '1=首页，2全站',
  `flink_order` int(11) DEFAULT '0' COMMENT '排序',
  `flink_time` int(10) unsigned NOT NULL COMMENT '添加时间',
  `uid` int(10) unsigned NOT NULL COMMENT 'uid',
  PRIMARY KEY (`flink_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='友情链接表';

