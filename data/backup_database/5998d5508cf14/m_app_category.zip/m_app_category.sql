#
# TABLE STRUCTURE FOR: m_app_category
#

DROP TABLE IF EXISTS `m_app_category`;

CREATE TABLE `m_app_category` (
  `cate_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '类别id',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '父类id',
  `cname` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名称',
  `cname_py` varchar(100) NOT NULL DEFAULT '' COMMENT '分类字母别名',
  `ctitle` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `ckey` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `cdesc` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `corder` int(11) NOT NULL DEFAULT '0' COMMENT '分类排序',
  `cat_show` int(2) NOT NULL DEFAULT '1' COMMENT '是否显示分类',
  `cate_logo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '分类图标',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='分类表';

INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('1', '2', '休闲益智', 'lifeedu', '', '', '', '0', '1', '/templates/cates/lifeedu.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('2', '1', '影音图像', 'video', '', '', '', '0', '1', '/templates/cates/videoimage.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('3', '1', '阅读学习', 'reading', '', '', '', '0', '1', '/templates/cates/reading.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('4', '1', '实用工具', 'tool', '', '', '', '0', '1', '/templates/cates/toolp.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('5', '2', '经营策略', 'strategy', '', '', '', '0', '1', '/templates/cates/strategy.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('6', '2', '角色扮演', 'role', '', '', '', '0', '1', '/templates/cates/role.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('7', '2', '策略', 'gamestrategy', '', '', '', '0', '1', '/templates/cates/gamestrategy.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('8', '2', '网络游戏', 'netgames', '', '', '', '0', '1', '/templates/cates/netgames.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('9', '2', '飞行射击', 'flyshoot', '', '', '', '0', '1', '/templates/cates/flightShooting.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('10', '1', '健康医疗', 'strong', '', '', '', '0', '1', '/templates/cates/strong.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('11', '1', '旅游酒店', 'travel', '', '', '', '0', '1', '/templates/cates/travel.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('12', '2', '社交游戏', 'socialgame', '', '', '', '0', '1', '/templates/cates/socialgame.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('13', '1', '金融理财', 'finance', '', '', '', '0', '1', '/templates/cates/finance.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('14', '1', '生活地图', 'map', '', '', '', '0', '1', '/templates/cates/maplife.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('15', '1', '办公商务', 'office', '', '', '', '0', '1', '/templates/cates/office.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('16', '1', '聊天通讯', 'chat', '', '', '', '0', '1', '/templates/cates/chat.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('17', '1', '购物优惠', 'shopcoupon', '', '', '', '0', '1', '/templates/cates/shopcoupon.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('18', '1', '儿童亲子', 'childen', '', '', '', '0', '1', '/templates/cates/childen.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('19', '1', '教育学习', 'studying', '', '', '', '0', '1', '/templates/cates/study.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('20', '1', '地图旅游', 'tour', '', '', '', '0', '1', '/templates/cates/tourmap.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('21', '1', '系统安全', 'sysinput', '', '', '', '0', '1', '/templates/cates/sysinput.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('22', '1', '壁纸主题', 'wallpaper', '', '', '', '0', '1', '/templates/cates/wallpaper.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('23', '1', '摄影摄像', 'pai', '', '', '', '0', '1', '/templates/cates/pai.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('24', '2', '棋牌天地', 'chess', '', '', '', '0', '1', '/templates/cates/chess.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('25', '2', '跑酷', 'parkour', '', '', '', '0', '1', '/templates/cates/parkour.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('26', '2', '格斗', 'wrestle', '', '', '', '0', '1', '/templates/cates/wrestle.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('27', '2', '竞技游戏', 'sportsgame', '', '', '', '0', '1', '/templates/cates/sportsgame.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('28', '2', '模拟辅助', 'analog', '', '', '', '0', '1', '/templates/cates/analog.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('29', '2', '体育竞速', 'racing', '', '', '', '0', '1', '/templates/cates/racing.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('30', '2', '其它', 'other', '', '', '', '0', '1', '/templates/cates/other.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('31', '2', '动作', 'action', '', '', '', '0', '1', '/templates/cates/action.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('32', '2', '塔防', 'tower', '', '', '', '0', '1', '/templates/cates/tower.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('33', '2', '体育', 'physical', '', '', '', '0', '1', '/templates/cates/physical.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('34', '2', '动作冒险', 'actions', '', '', '', '0', '1', '/templates/cates/actions.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('35', '2', '儿童游戏', 'childgame', '', '', '', '0', '1', '/templates/cates/childgame.png');
INSERT INTO `m_app_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`, `cate_logo`) VALUES ('37', '2', '养成', 'develop', '', '', '', '0', '1', '/templates/cates/develop.png');


