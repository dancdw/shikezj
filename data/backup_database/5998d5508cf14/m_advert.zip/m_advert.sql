#
# TABLE STRUCTURE FOR: m_advert
#

DROP TABLE IF EXISTS `m_advert`;

CREATE TABLE `m_advert` (
  `ad_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ad_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '广告标题',
  `ad_type` tinyint(3) unsigned NOT NULL COMMENT '广告类型1PC轮播 2手机轮播',
  `ad_alts` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '图片文字',
  `ad_images` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '广告图片',
  `ad_links` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '广告链接',
  `ad_remarks` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '备注',
  `ad_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `uid` int(10) unsigned NOT NULL COMMENT '添加人',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='推荐位置（广告，推荐位，专题）';

INSERT INTO `m_advert` (`ad_id`, `ad_title`, `ad_type`, `ad_alts`, `ad_images`, `ad_links`, `ad_remarks`, `ad_time`, `uid`) VALUES ('30', 'PC网站首页轮播', '1', 'pc|test', '/uploads/images/36678d549cc10510616ba43f81b3c61f.jpg|/uploads/images/2bec98d452f11fe936ccbe3934ffa465.jpg', '/index.php?c=index&m=content_app&app_id=264|http://www.711cms.com', '', '1441013282', '1');
INSERT INTO `m_advert` (`ad_id`, `ad_title`, `ad_type`, `ad_alts`, `ad_images`, `ad_links`, `ad_remarks`, `ad_time`, `uid`) VALUES ('31', '手助首页轮播', '3', '手助广告第一屏|手助广告第二屏', '/uploads/images/29c6506d0c5f74d3de60dc7beb8301ed.png|/uploads/images/2bec98d452f11fe936ccbe3934ffa465.jpg', '1|2', '', '1444462466', '1');
INSERT INTO `m_advert` (`ad_id`, `ad_title`, `ad_type`, `ad_alts`, `ad_images`, `ad_links`, `ad_remarks`, `ad_time`, `uid`) VALUES ('32', 'WAP首页轮播', '2', 'wap', '/uploads/images/29c6506d0c5f74d3de60dc7beb8301ed.png', 'http://www.711cms.com', '', '1445321845', '1');


