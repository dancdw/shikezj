#
# TABLE STRUCTURE FOR: m_resource
#

DROP TABLE IF EXISTS `m_resource`;

CREATE TABLE `m_resource` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '资源',
  `info_app_id` int(11) NOT NULL DEFAULT '0' COMMENT '应用 或资讯ID',
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '关联的类型，应用=0，资讯=1',
  `resource_url` varchar(300) NOT NULL DEFAULT '' COMMENT '资源地址',
  `width` int(11) NOT NULL DEFAULT '0' COMMENT '资源宽度',
  `height` int(11) NOT NULL DEFAULT '0' COMMENT '资源高度',
  `size` int(11) NOT NULL DEFAULT '0' COMMENT '资源大小',
  PRIMARY KEY (`id`),
  KEY `id_type` (`info_app_id`,`type`),
  KEY `resource_url` (`resource_url`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COMMENT='资源表';

INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('1', '1', '0', 'http://p15.qhimg.com/t01a51aa3e5b4b4bdf6.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('2', '1', '0', 'http://p19.qhimg.com/t017449ae7e2d3b7016.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('3', '1', '0', 'http://p19.qhimg.com/t016605aeffc0aa8887.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('4', '1', '0', 'http://p17.qhimg.com/t01119208d29c0ba2b3.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('5', '1', '0', 'http://p16.qhimg.com/t01a1600c26831e03d0.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('6', '2', '0', 'http://p17.qhimg.com/t0135cb30a6a7584382.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('7', '2', '0', 'http://p16.qhimg.com/t01620fcd4bd6566223.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('8', '2', '0', 'http://p17.qhimg.com/t01a9e8b75ab5360fed.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('9', '2', '0', 'http://p17.qhimg.com/t01df8a9ec4d12b9d70.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('10', '2', '0', 'http://p17.qhimg.com/t01cb68fdec833de022.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('11', '3', '0', 'http://p15.qhimg.com/t01b4355ec6d5bace58.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('12', '3', '0', 'http://p17.qhimg.com/t015287dbd6c81b43ee.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('13', '3', '0', 'http://p19.qhimg.com/t01e882837746ffa40b.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('14', '3', '0', 'http://p17.qhimg.com/t01557476f024da1eaf.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('15', '3', '0', 'http://p19.qhimg.com/t017fbe58e24aa31170.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('16', '4', '0', 'http://p19.qhimg.com/t01b8082c429aa4b4d5.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('17', '4', '0', 'http://p15.qhimg.com/t01b684fde76e882513.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('18', '4', '0', 'http://p18.qhimg.com/t019da21d101e14add1.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('19', '4', '0', 'http://p17.qhimg.com/t01c15070a5ec92ee3e.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('20', '4', '0', 'http://p16.qhimg.com/t01efc89c2e2f673c0c.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('21', '5', '0', 'http://p19.qhimg.com/t0188462b418890357c.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('22', '5', '0', 'http://p15.qhimg.com/t0198235422d6cf1854.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('23', '5', '0', 'http://p17.qhimg.com/t014f9821af9095768c.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('24', '5', '0', 'http://p17.qhimg.com/t01c10e21151da5e264.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('25', '5', '0', 'http://p15.qhimg.com/t01212eb16984e5dcca.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('26', '6', '0', 'http://p17.qhimg.com/t012b86b0cc7fba671e.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('27', '6', '0', 'http://p17.qhimg.com/t01f8f70660c1fd3f3c.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('28', '6', '0', 'http://p15.qhimg.com/t0152f0eab8eba390ed.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('29', '6', '0', 'http://p16.qhimg.com/t01b749301128c42424.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('30', '6', '0', 'http://p19.qhimg.com/t018dd71d0cab155dbd.png', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('31', '7', '0', 'http://p18.qhimg.com/t01cf4f198afaa8f99b.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('32', '7', '0', 'http://p15.qhimg.com/t012a1389e54e064023.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('33', '7', '0', 'http://p19.qhimg.com/t01e2fffb9d071495da.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('34', '7', '0', 'http://p16.qhimg.com/t016b41bfec6a6a5eab.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('35', '8', '0', 'http://p16.qhimg.com/t01a3148273e75e0bf4.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('36', '8', '0', 'http://p15.qhimg.com/t017cd7f2917af83013.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('37', '8', '0', 'http://p19.qhimg.com/t01483a3d3fbf882570.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('38', '8', '0', 'http://p15.qhimg.com/t01f11c4c338d722618.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('39', '8', '0', 'http://p19.qhimg.com/t012d509b972c8c297a.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('40', '9', '0', 'http://p15.qhimg.com/t01c7f1d3544cadf35a.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('41', '9', '0', 'http://p16.qhimg.com/t0166b22550db563826.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('42', '9', '0', 'http://p19.qhimg.com/t011c29f07ad0d4476f.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('43', '9', '0', 'http://p18.qhimg.com/t01b72aecea764b3a0d.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('44', '9', '0', 'http://p18.qhimg.com/t01fd588190d3d29c76.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('45', '10', '0', 'http://p19.qhimg.com/t015ddf766e5b6fa24c.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('46', '10', '0', 'http://p16.qhimg.com/t01c0b692b8136e6be9.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('47', '10', '0', 'http://p16.qhimg.com/t01ecf4c78f95f04191.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('48', '10', '0', 'http://p17.qhimg.com/t013004af84d5a11bd6.jpg', '0', '0', '0');
INSERT INTO `m_resource` (`id`, `info_app_id`, `type`, `resource_url`, `width`, `height`, `size`) VALUES ('49', '10', '0', 'http://p17.qhimg.com/t01a060a98b1b65c5ee.jpg', '0', '0', '0');


