#
# TABLE STRUCTURE FOR: m_special
#

DROP TABLE IF EXISTS `m_special`;

CREATE TABLE `m_special` (
  `area_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `area_title` text NOT NULL COMMENT '位置标题',
  `area_html` text COMMENT '广告HTML或者描述文本',
  `area_remarks` varchar(1000) NOT NULL DEFAULT '' COMMENT '备注',
  `area_logo` varchar(200) NOT NULL DEFAULT '' COMMENT '位置LOGO图',
  `area_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `area_ids` text NOT NULL COMMENT 'ID列表，用逗号分割',
  `special_seotitle` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `special_seokey` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `special_seodesc` varchar(2048) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `special_time` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='专题';

INSERT INTO `m_special` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `special_seotitle`, `special_seokey`, `special_seodesc`, `special_time`, `uid`) VALUES ('32', '专题二', '', '', '/uploads/images/b01f7bee4cebf5bfd322328fd0949fdb.gif', '0', '4,5,6', '', '', '', '1445411835', '1');
INSERT INTO `m_special` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `special_seotitle`, `special_seokey`, `special_seodesc`, `special_time`, `uid`) VALUES ('33', '专题三', '', '', '/uploads/images/ddb4cb8830d76ae2326570b620eb058d.gif', '0', '7,8,9', '', '', '', '1445411841', '1');
INSERT INTO `m_special` (`area_id`, `area_title`, `area_html`, `area_remarks`, `area_logo`, `area_order`, `area_ids`, `special_seotitle`, `special_seokey`, `special_seodesc`, `special_time`, `uid`) VALUES ('31', '专题一', '', '', '/uploads/images/80de3333fd830896e60368592175355b.gif', '0', '1,2,3', '', '', '', '1445411827', '1');


