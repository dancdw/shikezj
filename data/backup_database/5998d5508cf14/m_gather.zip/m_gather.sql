#
# TABLE STRUCTURE FOR: m_gather
#

DROP TABLE IF EXISTS `m_gather`;

CREATE TABLE `m_gather` (
  `gather_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gather_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '采集名称',
  `gather_site` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '网站地址',
  `cate_id` int(10) unsigned NOT NULL COMMENT '采集分类',
  `gather_charset` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '页面编码',
  `gather_is_local` tinyint(3) unsigned NOT NULL COMMENT '是否本地化图片',
  `gather_index_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '列表首页地址',
  `gather_list_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '列表页地址',
  `gather_page_start` int(10) unsigned NOT NULL COMMENT '列表开始页',
  `gather_page_end` int(10) unsigned NOT NULL COMMENT '列表结束页',
  `gather_list_sign` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章列表标签',
  `gather_list_link` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '列表链接标签',
  `gather_title_sign` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '文章标题标签',
  `gather_content_sign` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '内容标题标签',
  `gather_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`gather_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='采集信息表';

INSERT INTO `m_gather` (`gather_id`, `gather_name`, `gather_site`, `cate_id`, `gather_charset`, `gather_is_local`, `gather_index_url`, `gather_list_url`, `gather_page_start`, `gather_page_end`, `gather_list_sign`, `gather_list_link`, `gather_title_sign`, `gather_content_sign`, `gather_time`, `uid`) VALUES ('1', '新作前瞻', 'http://wy.92wy.com', '2', 'UTF-8', '1', '', 'http://wy.92wy.com/news/30/list_{page}.html', '1', '1', '.list2', 'li a', 'h2,h3', '.info_text_con,.articlecontent', '1440760845', '1');
INSERT INTO `m_gather` (`gather_id`, `gather_name`, `gather_site`, `cate_id`, `gather_charset`, `gather_is_local`, `gather_index_url`, `gather_list_url`, `gather_page_start`, `gather_page_end`, `gather_list_sign`, `gather_list_link`, `gather_title_sign`, `gather_content_sign`, `gather_time`, `uid`) VALUES ('2', '手机网游攻略', 'http://sj.xiaopi.com', '3', 'UTF-8', '1', '', 'http://sj.xiaopi.com/news/gonglue_{page}.html', '2', '3', '.wzlb_list', '.wzlb_list_img a', '.top_title', '.article_main', '1440926227', '1');
INSERT INTO `m_gather` (`gather_id`, `gather_name`, `gather_site`, `cate_id`, `gather_charset`, `gather_is_local`, `gather_index_url`, `gather_list_url`, `gather_page_start`, `gather_page_end`, `gather_list_sign`, `gather_list_link`, `gather_title_sign`, `gather_content_sign`, `gather_time`, `uid`) VALUES ('3', '安卓资讯', 'http://android.d.cn', '4', 'UTF-8', '1', '', 'http://android.d.cn/news/0/-1/{page}/', '2', '3', '.info-list', '.first  a', '.article h1', '#content', '1442307687', '1');


