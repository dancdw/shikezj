#
# TABLE STRUCTURE FOR: m_info
#

DROP TABLE IF EXISTS `m_info`;

CREATE TABLE `m_info` (
  `info_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '资讯id',
  `last_cate_id` int(11) NOT NULL DEFAULT '0' COMMENT '终极分类ID',
  `info_title` varchar(500) NOT NULL DEFAULT '' COMMENT '标题',
  `info_stitle` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `info_img` varchar(500) NOT NULL DEFAULT '' COMMENT '缩略图',
  `info_desc` varchar(500) NOT NULL DEFAULT '' COMMENT '摘要',
  `info_body` text COMMENT '详情',
  `info_tags` varchar(1000) NOT NULL DEFAULT '' COMMENT '标签',
  `info_update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `info_from` varchar(500) NOT NULL DEFAULT '' COMMENT '来源',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '发布人ID',
  `info_comments` int(11) NOT NULL DEFAULT '0' COMMENT '评论量',
  `info_visitors` int(11) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `info_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `info_url` varchar(500) NOT NULL DEFAULT '' COMMENT '外部URL',
  `info_publish_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '发表时间',
  `info_seodesc` varchar(256) NOT NULL DEFAULT '' COMMENT 'seodesc',
  `info_seokey` varchar(256) NOT NULL DEFAULT '' COMMENT 'seokey',
  `info_status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `info_author` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '作者',
  PRIMARY KEY (`info_id`),
  KEY `cate_update_time` (`last_cate_id`,`info_update_time`),
  KEY `cate_order` (`last_cate_id`,`info_order`),
  KEY `cate_visitor` (`last_cate_id`,`info_visitors`),
  KEY `cate_create_time` (`last_cate_id`,`create_time`),
  KEY `info_update_time` (`info_update_time`),
  KEY `info_order` (`info_order`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='资讯表';

INSERT INTO `m_info` (`info_id`, `last_cate_id`, `info_title`, `info_stitle`, `info_img`, `info_desc`, `info_body`, `info_tags`, `info_update_time`, `create_time`, `info_from`, `uid`, `info_comments`, `info_visitors`, `info_order`, `info_url`, `info_publish_time`, `info_seodesc`, `info_seokey`, `info_status`, `info_author`) VALUES ('24', '4', '《NBA英雄》柏林英雄礼 诺天王伟大的告别', '《NBA英雄》柏林英雄礼 诺天王伟大的告别', '', '', '<p>　2015年欧洲男子篮球锦标赛，德国队对阵西班牙队之前获得1胜3负的战绩，只有赢下这场比赛才有出现的机会。可惜最终事与愿违，德国队遗憾落败，为本届欧洲男子篮球锦标赛画上并不完美的句号。最温情的画面莫过于最终结束时，属于德克·诺维茨基的时刻。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　德国对西班牙的男篮欧锦赛小组赛结束后，当诺维茨基转身走回赛场中间，他立刻得到了全场观众的鼓掌欢呼，诺天王向四周观众席几次挥手、鞠躬，作为一名土生土长的德国人，诺维茨基在主场球迷的欢呼声中，情不自禁流下了激动的泪水，最后用球衣拭去脸上的泪水，消失在球员通道。这也许是37岁的老男孩最后一次身披德国国家队队服出战，泪洒球场诉说这位德国英雄的传奇生涯。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　“感谢大家这一周时间的支持，感谢你们赠与我一场伟大的告别。”诺维茨基赛后在社交网络上这样写道，“这个时刻我永生不忘，对我而言这始终是一份荣耀。”诺维茨基为了欧锦赛如此卖力备战，而他在国家队中的核心地位也已让给了老鹰队后卫施罗德。对阵西班牙的比赛中，诺维茨基在西班牙队米罗蒂奇的贴身盯防下无所适从，但他依然能在最后时刻命中关键球，带领球队奋起反击。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　如今在球队中已不再是头号得分手，但诺维茨基绝对是球队的精神领袖，他在国家队中经历的一切，足以成为一笔宝贵的精神财富。“他是一位伟大的运动员，也是一位实现伟大梦想的德国人。”德国总理默克尔曾这样评价诺维茨基，“篮球并不是德国最受欢迎的运动，但他让更多人热爱上篮球，这是值得被赞扬的。”</p>\r\n', '', '1442988423', '1442199952', '', '1', '0', '1', '0', '', '0', '《NBA英雄》柏林英雄礼 诺天王伟大的告别', '《NBA英雄》柏林英雄礼 诺天王伟大的告别', '1', '');
INSERT INTO `m_info` (`info_id`, `last_cate_id`, `info_title`, `info_stitle`, `info_img`, `info_desc`, `info_body`, `info_tags`, `info_update_time`, `create_time`, `info_from`, `uid`, `info_comments`, `info_visitors`, `info_order`, `info_url`, `info_publish_time`, `info_seodesc`, `info_seokey`, `info_status`, `info_author`) VALUES ('25', '3', '打造完美恋人 《正妹物语》女友养成记', '', '', '', '<p>“夏天夏天悄悄过去留下小秘密 压心底 压心底 不能告诉你~晚风吹过温暖我心底 我又想起你 多甜蜜 多甜蜜 怎能忘记~”哈哈，夏天就剩下一个小尾巴了，你的粉红色记忆找到了吗?没有到话就来《正妹物语》看看吧，好多好多漂亮可爱的萌妹子都在这等着你哦~</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　由深圳微讯移通独家代理的真人女友恋爱养成手游《正妹物语》手把手教你泡正妹，各色女神任君挑选，性感魅惑、清纯可人、温柔体贴、妩媚动人...只要你要，只要我有。养成完美恋人，百变女神给你前所未有的恋爱新体验，夏日脱单ing~</p>\r\n\r\n<p>　　天气正慢慢褪去燥热，但玩家们的热情却持续上升，为了和女神交盆友，大家也是蛮拼的~好吧，为了回馈众男神，《正妹物语》又要出大招了，这一发的大招绝对甜到你心里!!</p>\r\n\r\n<p>　　没有错!又有新女神要来做你们的女朋友啦!高不高兴，期不期待，嗨不嗨!世界都变美好了对不对!哈哈，这次新版本即将上线的妹纸到底是个什么类型的女神呢?小编表示，这次的妹子绝对是所有男性无法抗拒的诱惑，想要吗><</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　新鲜的女神就像多汁的水蜜桃一样诱人，但是想吃到可不是那么容易的事情哦~耐心等待吧，新版本上线之日，就是迎娶女神之时，后宫妹子那么多，可都要好好安抚哟~除此之外，《正妹物语》公测即将开启，到时候又有一大波惊喜等着大家咯，鸡血打起来，人生巅峰就要来啦!!</p>\r\n\r\n<p>　　快来《正妹物语》领个女友回家养着吧，会撒娇会卖萌长得漂亮身材巨棒，女神将临，你准备好了吗~</p>\r\n', '', '1442988416', '1442200092', '', '1', '0', '2', '0', '', '0', '', '', '1', '');
INSERT INTO `m_info` (`info_id`, `last_cate_id`, `info_title`, `info_stitle`, `info_img`, `info_desc`, `info_body`, `info_tags`, `info_update_time`, `create_time`, `info_from`, `uid`, `info_comments`, `info_visitors`, `info_order`, `info_url`, `info_publish_time`, `info_seodesc`, `info_seokey`, `info_status`, `info_author`) VALUES ('26', '4', '决战魔窟 《魔力时代》英魂圣能之战', '', '', '', '<p>《魔力时代》常用的游戏资源除了金币和钻石之外，还有英魂和圣能。《魔力时代》中没有“穷人”，只有不努力获取资源的人。所有你所需要的资源，你都可以通过在游戏攻打副本或者其他玩法来获取，英魂和圣能也是如此，勇者们快到深渊魔窟中战斗，抢夺英魂和圣能吧!</p>\r\n', '', '1444981482', '1442200229', '', '1', '0', '0', '0', '', '1444981508', '', '', '2', '');
INSERT INTO `m_info` (`info_id`, `last_cate_id`, `info_title`, `info_stitle`, `info_img`, `info_desc`, `info_body`, `info_tags`, `info_update_time`, `create_time`, `info_from`, `uid`, `info_comments`, `info_visitors`, `info_order`, `info_url`, `info_publish_time`, `info_seodesc`, `info_seokey`, `info_status`, `info_author`) VALUES ('23', '2', '《全民飞机大战》太阳级新战机嫦娥测评', '《全民飞机大战》太阳级新战机嫦娥测评', '', '', '<p>《全民飞机大战》宠物革新时代降临，神级皇冠宠物纷纷登场，掀起合宠热潮!此次，神宠版本再添惊喜，拥有更强属性、更全面技能的太阳战机——嫦娥强势上架商城!首款太阳战机会有怎样的表现?小编带大家一起揭晓!</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　嫦娥满级属性：</p>\r\n\r\n<p>　　品质：三太阳</p>\r\n\r\n<p>　　生命值：1600</p>\r\n\r\n<p>　　攻击力：2180</p>\r\n\r\n<p>　　攻击速度：250</p>\r\n\r\n<p>　　战机技能：</p>\r\n\r\n<p>　　【弦乐之舞】：每损失300生命(双打模式为600)时舞蹈弦乐之舞将屏幕内的敌机变成伴舞的兔子，兔子移动速度降低，停止发射子弹，舞蹈时流转的圆刃秒杀周围敌机，并对boss或首领造成伤害，持续8秒，释放期间嫦娥免伤。技能开始与结束时均造成清屏爆炸，累积最高造成1000000伤害。</p>\r\n\r\n<p>　　【圆月之舞】：主动使用后与友机同时进入免伤状态，并召唤出共同控制的灵体舞蹈圆月之舞将屏幕内的敌机变成伴舞的兔子，兔子移动速度降低，停止发射子弹，期间对全屏敌机造成伤害，舞蹈时流转的圆刃秒杀周围的敌机，并对boss或首领造成伤害，持续12秒。技能释放前后均造成清屏爆炸，累积最高造成1600000伤害。冷却时间300秒。</p>\r\n\r\n<p>　　【月轮斩】：每秒发射2个圆刃，共造成5000伤害。</p>\r\n\r\n<p>　　【月华冰心】：击杀boss或首领回血320点，并且最终结算时，击杀boss或首领的基础得分加成160%，友机基础得分加成80%。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　嫦娥不愧为帝俊之女、后羿之妻，不仅貌美非凡，实力也不容小觑。作为《全民飞机大战》首架太阳级战机，嫦娥的等级可升至100，攻击速度为战机最高水平，满级攻击力与生命力也远超月亮级战机登上顶峰。如此娇艳美人、如此强势属性，定会迎来新一轮购机狂潮!</p>\r\n\r\n<p>　　而更为逆天的则是嫦娥的技能设定，不仅实用强力，在弹幕和技能释放的视觉效果上也是绝佳!嫦娥拥有四项技能，且有三项技能都为双打模式做了特别设计。“月华冰心”不仅拥有得分加成，击杀boss还可回血，增强战机续航能力;配合“弦乐之舞”这一华丽的损血技能，所有敌机都变成人畜无害的兔子，嫦娥挥舞圆刃瞬杀敌机，并能对boss或首领造成极高伤害，还有二重清屏效果再增输出，就是如此暴力，就是这么任性!</p>\r\n\r\n<p>　　嫦娥还拥有首项主动技能“圆月之舞”，免伤加超高输出、全屏伤害再加双重清屏，绝对神技!更惊喜的是，在双打模式下，除自身可用之外，友军也会拥有免伤状态，并控制灵体舞蹈，双打更加游刃有余，与好友更轻松遨游飞行上空!触发被动和主动时，嫦娥处于是无敌状态，释放技能无障碍!“月轮斩”则进一步加强了嫦娥的输出能力，可分担旁支威胁。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　在搭配上，小编推荐天空三件套，如果没有天空也可铁流套装，都是高伤高防的组合。小编宠物搭配了月宫神兔与幽蓝之星，护盾加回血续航能力可见一斑，攻击加成为战机增强输出，还有得分加成为玩家登榜再添一力。有了这样完美的搭配，无论遇到多刁难的boss都能无所畏惧轻易击杀!</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　嫦娥作为首架太阳战机，属性为现今最高，技能也极其强势，是非常完美的战机。而且在活动期间将嫦娥升到满级还可获赠皇冠宠月宫神兔，嫦娥搭配月兔当然是极好的，心动的玩家可别错过了!</p>\r\n', '', '1442988428', '1442199542', '', '1', '0', '33', '0', '', '0', '《全民飞机大战》太阳级新战机嫦娥测评', '《全民飞机大战》太阳级新战机嫦娥测评', '1', '');
INSERT INTO `m_info` (`info_id`, `last_cate_id`, `info_title`, `info_stitle`, `info_img`, `info_desc`, `info_body`, `info_tags`, `info_update_time`, `create_time`, `info_from`, `uid`, `info_comments`, `info_visitors`, `info_order`, `info_url`, `info_publish_time`, `info_seodesc`, `info_seokey`, `info_status`, `info_author`) VALUES ('22', '4', '科幻手游《小兵传奇》公测火爆开启 同名小说正版授权', '', '', '', '<p>在9月12日，由广州49You重金独代、网络人气作家玄雨授权并亲自监制、2015年超高期待的同名科幻手游《小兵传奇》已经华丽开启全网公测。公测后如何在最快时间融入游戏也是玩家们关心的话题，今天咱们就来为新手们支一招，看看前辈们都是怎么在游戏中捷足先登的吧!</p>\r\n\r\n<p>　　在49You《小兵传奇》这款游戏里面，阵型搭配是非常讲究的，而且阵型也是非常中国传统兵法特色。《孙子兵法》读得再多也都是纸上谈兵，咱们到了这里就要学会实战运用，而这，就是49You《小兵传奇》一大亮点之一。玩家要合理根据英雄的属性，来决定前后排站位，从而组成最高的输出战力。同时也要合理安排替补，以便应对突发情况。如果你平时有看足球篮球比赛，场边那个运筹帷幄、掌控全局的主教练就是你在《小兵传奇》中的形象哦!</p>\r\n\r\n<p><img alt=\"小兵传奇公测\" src=\"http://www.xiaopi.com/game/uploadfile/2015/0914/20150914093653784.jpg\" /></p>\r\n\r\n<p>　　英雄系统是玩法中的重点，而命运系统又是决定英雄战斗力的关键玩法。49You《小兵传奇》里英雄的战斗力除了来源于自身能力和道具装备外，更加依赖于自身与其他上阵英雄或特定装备产生的“命运”。替补中的角色也是可以作为出阵英雄存在的，上阵英雄的“命运”除了阵内角色外，与替补英雄同样也可以产生联系。这样一来就可以产生多种多样的命运组合啦，赶紧去试一试啦。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　在新游戏里，大家往往会东转西转找不到北，错过最佳练级和成长的机会，49You《小兵传奇》为大家提供了一个很好的平台方便大家完成每天的任务，更快的升级进阶，从此妈妈再也不用担心我的战斗力了!只要有体力就去刷图，有体力药剂就猛磕体力药剂，每天买满体力药剂，买满各种箱子开出体力药剂，级别就能拉开很多。</p>\r\n\r\n<p> </p>\r\n\r\n<p>　　除此之外，公测开启的同时伴随着还有众多豪礼来袭，比如像登陆有惊喜、累积充值等等活动都一一俱全;并且还会有星际动荡“天下第一”、“命运北斗”再次开启这样的趣味活动同步上线!而且所有充值项首充都可以获得双倍返还，并且充值就送10%，充值100元以上可获送15%，赶紧来参加吧!</p>\r\n', '', '1442988434', '1442199465', '711cms', '1', '0', '12', '0', '', '0', '', '', '1', '');


