#
# TABLE STRUCTURE FOR: m_admin
#

DROP TABLE IF EXISTS `m_admin`;

CREATE TABLE `m_admin` (
  `uid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uname` varchar(100) NOT NULL DEFAULT '' COMMENT '账号',
  `upass` varchar(100) NOT NULL DEFAULT '' COMMENT '密码',
  `ustate` int(2) NOT NULL DEFAULT '1' COMMENT '用户状态（正常=1）',
  `reg_date` int(11) NOT NULL DEFAULT '0' COMMENT '开通时间',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='后台管理表';

INSERT INTO `m_admin` (`uid`, `uname`, `upass`, `ustate`, `reg_date`) VALUES ('1', 'dancdw', '1282c8e96444603c03bdb97f5aa6760f', '1', '1503188235');


