#
# TABLE STRUCTURE FOR: m_app_comment
#

DROP TABLE IF EXISTS `m_app_comment`;

CREATE TABLE `m_app_comment` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论id',
  `info_app_id` int(11) NOT NULL COMMENT '应用id，资讯id',
  `comment_content` varchar(500) NOT NULL DEFAULT '' COMMENT '评论内容',
  `comment_date` int(11) NOT NULL COMMENT '发布时间',
  `comment_user` int(11) NOT NULL COMMENT '用户id',
  `comment_uname` varchar(500) NOT NULL DEFAULT '' COMMENT '昵称',
  `comment_ip` varchar(15) NOT NULL COMMENT 'ip地址',
  `comment_parent` int(11) unsigned NOT NULL COMMENT '上级id',
  `comment_check` tinyint(4) unsigned NOT NULL COMMENT '是否审核',
  `comment_good` int(11) unsigned NOT NULL COMMENT '赞',
  `comment_bad` int(11) unsigned NOT NULL COMMENT '踩',
  PRIMARY KEY (`comment_id`),
  KEY `id_type` (`info_app_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='评论表';

