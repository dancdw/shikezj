#
# TABLE STRUCTURE FOR: m_setting
#

DROP TABLE IF EXISTS `m_setting`;

CREATE TABLE `m_setting` (
  `s_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_key` varchar(255) NOT NULL,
  `s_value` text NOT NULL,
  PRIMARY KEY (`s_id`),
  UNIQUE KEY `s_key` (`s_key`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='设置表';

INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('1', 'auth_code', 'f3000e8542396594a81f6e07be177210');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('2', 'cache_time', '0');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('3', 'comment_code', '');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('4', 'count_code', '');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('5', 'data_center_url', 'http://www.711cms.com/api');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('6', 'pagesize', '20');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('7', 'version', '1.0.0');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('8', 'update_time', '1503188235');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('9', 'static_url', 'static');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('10', 'water_button', '2');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('11', 'is_site_rewrite', '-1');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('12', 'is_content_mobile', '1');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('13', 'is_images_local', '0');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('14', 'is_images_rewrite', '0');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('15', 'is_content_nlink', '0');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('16', 'seo_description', '711cms');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('17', 'seo_keywords', '711cms');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('18', 'seo_title', '711cms');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('19', 'site_logo', '/uploads/images/9604a4f67391f4dc1010dce413c373ac.png');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('20', 'site_name', '711cms网站名称');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('21', 'site_safe_code', '');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('22', 'site_url', 'http://localhost');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('23', 'site_beian', '');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('24', 'site_copyright', '');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('25', 'site_path', '/');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('26', 'template', 'template_001');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('27', 'upload_key', '33c2c07ec173aaead04a48fdac0185dc');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('28', 'upload_path', '/uploads/images/');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('29', 'upload_path_apk', '/uploads/apk/');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('30', 'wap_logo', '/uploads/images/9604a4f67391f4dc1010dce413c373ac.png');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('31', 'wap_url', 'http://localhost');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('32', 'wap_seo_description', '711cms');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('33', 'wap_seo_keywords', '711cms');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('34', 'wap_seo_title', '711cms');
INSERT INTO `m_setting` (`s_id`, `s_key`, `s_value`) VALUES ('35', 'wap_template', 'template_1');


