#
# TABLE STRUCTURE FOR: m_navicat
#

DROP TABLE IF EXISTS `m_navicat`;

CREATE TABLE `m_navicat` (
  `navicat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `navicat_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '导航名称',
  `navicat_url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '导航地址',
  `navicat_m` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `navicat_seotitle` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'seo标题',
  `navicat_seokey` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'seo关键字',
  `navicat_seodesc` varchar(2048) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'seo描述',
  `navicat_enabled` tinyint(3) unsigned NOT NULL COMMENT '是否可用',
  `navicat_order` tinyint(3) unsigned NOT NULL COMMENT '排序',
  `navicat_time` int(10) unsigned NOT NULL COMMENT '添加时间',
  `navicat_blank` tinyint(3) unsigned NOT NULL COMMENT '是否新窗口',
  `uid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`navicat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='导航表';

INSERT INTO `m_navicat` (`navicat_id`, `navicat_name`, `navicat_url`, `navicat_m`, `navicat_seotitle`, `navicat_seokey`, `navicat_seodesc`, `navicat_enabled`, `navicat_order`, `navicat_time`, `navicat_blank`, `uid`) VALUES ('2', '安卓软件', '/index.php?c=index&m=softs', 'softs', '', '', '', '1', '8', '1442141993', '2', '1');
INSERT INTO `m_navicat` (`navicat_id`, `navicat_name`, `navicat_url`, `navicat_m`, `navicat_seotitle`, `navicat_seokey`, `navicat_seodesc`, `navicat_enabled`, `navicat_order`, `navicat_time`, `navicat_blank`, `uid`) VALUES ('3', '安卓游戏', '/index.php?c=index&m=games', 'games', '', '', '', '1', '7', '1442127736', '2', '1');
INSERT INTO `m_navicat` (`navicat_id`, `navicat_name`, `navicat_url`, `navicat_m`, `navicat_seotitle`, `navicat_seokey`, `navicat_seodesc`, `navicat_enabled`, `navicat_order`, `navicat_time`, `navicat_blank`, `uid`) VALUES ('4', '装机必备', '/index.php?c=index&m=necessaries', 'necessaries', '', '', '', '1', '5', '1442127763', '2', '1');
INSERT INTO `m_navicat` (`navicat_id`, `navicat_name`, `navicat_url`, `navicat_m`, `navicat_seotitle`, `navicat_seokey`, `navicat_seodesc`, `navicat_enabled`, `navicat_order`, `navicat_time`, `navicat_blank`, `uid`) VALUES ('5', '资讯', '/index.php?c=index&m=infos', 'infos', '', '', '', '1', '6', '1442127788', '2', '1');
INSERT INTO `m_navicat` (`navicat_id`, `navicat_name`, `navicat_url`, `navicat_m`, `navicat_seotitle`, `navicat_seokey`, `navicat_seodesc`, `navicat_enabled`, `navicat_order`, `navicat_time`, `navicat_blank`, `uid`) VALUES ('6', '专题', '/index.php?c=index&m=specials', 'specials', '', '', '', '1', '4', '1442127813', '2', '1');
INSERT INTO `m_navicat` (`navicat_id`, `navicat_name`, `navicat_url`, `navicat_m`, `navicat_seotitle`, `navicat_seokey`, `navicat_seodesc`, `navicat_enabled`, `navicat_order`, `navicat_time`, `navicat_blank`, `uid`) VALUES ('7', '首页', '/', 'index', '', '', '', '1', '9', '1442127897', '2', '1');


