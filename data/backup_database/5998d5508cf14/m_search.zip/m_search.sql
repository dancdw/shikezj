#
# TABLE STRUCTURE FOR: m_search
#

DROP TABLE IF EXISTS `m_search`;

CREATE TABLE `m_search` (
  `q_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `q` varchar(200) NOT NULL DEFAULT '' COMMENT '搜索关键字',
  `qnum` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '搜索次数',
  `qorder` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '关键字排序',
  `q_type` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '关键字类型1.软件2.游戏',
  PRIMARY KEY (`q_id`),
  KEY `qorder` (`qorder`),
  KEY `q` (`q`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='搜索关键字记录表';

INSERT INTO `m_search` (`q_id`, `q`, `qnum`, `qorder`, `q_type`) VALUES ('1', '整除·4', '1', '0', '1');
INSERT INTO `m_search` (`q_id`, `q`, `qnum`, `qorder`, `q_type`) VALUES ('2', 'BesTV', '1', '0', '1');
INSERT INTO `m_search` (`q_id`, `q`, `qnum`, `qorder`, `q_type`) VALUES ('3', '一点资讯', '5', '0', '1');
INSERT INTO `m_search` (`q_id`, `q`, `qnum`, `qorder`, `q_type`) VALUES ('4', '今日头条', '5', '0', '1');
INSERT INTO `m_search` (`q_id`, `q`, `qnum`, `qorder`, `q_type`) VALUES ('5', '小黄人大眼萌乐园', '2', '0', '2');
INSERT INTO `m_search` (`q_id`, `q`, `qnum`, `qorder`, `q_type`) VALUES ('6', '万万没想到之大皇帝', '4', '0', '2');


