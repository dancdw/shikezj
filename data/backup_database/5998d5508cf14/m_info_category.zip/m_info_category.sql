#
# TABLE STRUCTURE FOR: m_info_category
#

DROP TABLE IF EXISTS `m_info_category`;

CREATE TABLE `m_info_category` (
  `cate_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '类别id',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '父类id',
  `cname` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名称',
  `cname_py` varchar(100) NOT NULL DEFAULT '' COMMENT '分类字母别名',
  `ctitle` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `ckey` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO关键词',
  `cdesc` varchar(500) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `corder` int(11) NOT NULL DEFAULT '0' COMMENT '分类排序',
  `cat_show` int(2) NOT NULL DEFAULT '1' COMMENT '是否显示分类',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='分类表';

INSERT INTO `m_info_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`) VALUES ('2', '1', '热门资讯', 'hot', '', '', '', '0', '1');
INSERT INTO `m_info_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`) VALUES ('3', '1', '游戏攻略', 'game', '', '', '', '0', '1');
INSERT INTO `m_info_category` (`cate_id`, `parent_id`, `cname`, `cname_py`, `ctitle`, `ckey`, `cdesc`, `corder`, `cat_show`) VALUES ('4', '1', '安卓资讯', 'android', '', '', '', '0', '1');


