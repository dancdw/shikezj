#
# TABLE STRUCTURE FOR: m_necessary
#

DROP TABLE IF EXISTS `m_necessary`;

CREATE TABLE `m_necessary` (
  `necessary_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `necessary_title` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '位置标题',
  `necessary_type` tinyint(4) unsigned NOT NULL COMMENT '类型',
  `necessary_remarks` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '备注',
  `necessary_html` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '简介',
  `necessary_order` int(11) unsigned NOT NULL COMMENT '排序',
  `necessary_list` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'ID列表',
  `necessary_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `uid` int(10) unsigned NOT NULL COMMENT 'uid',
  PRIMARY KEY (`necessary_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='装机必备';

INSERT INTO `m_necessary` (`necessary_id`, `necessary_title`, `necessary_type`, `necessary_remarks`, `necessary_html`, `necessary_order`, `necessary_list`, `necessary_time`, `uid`) VALUES ('29', '游戏必备', '2', '游戏必备', '游戏必备', '0', '1,2,3', '1444960000', '1');
INSERT INTO `m_necessary` (`necessary_id`, `necessary_title`, `necessary_type`, `necessary_remarks`, `necessary_html`, `necessary_order`, `necessary_list`, `necessary_time`, `uid`) VALUES ('30', '软件必备', '1', '软件必备', '软件必备', '0', '4,5,6', '1444959997', '1');


